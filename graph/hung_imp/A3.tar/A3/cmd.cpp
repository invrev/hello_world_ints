// ============================================================================
// cmd.cpp
// ~~~~~~~
// author : JOHN DOE
// - implement the two main commands: validate and display
// - this is the only file you can modify and submit
// ============================================================================

#include <iostream>
#include <sstream>
#include <stack>
#include <map>

#include "cmd.h"
#include "Lexer.h" // you should make use of the provided Lexer
#include "term_control.h"
#include "error_handling.h"

using namespace std;

/**
 * -----------------------------------------------------------------------------
 *  TO BE IMPLEMENTED BY YOU
 *  check whether the given expression is well-formed and print it out
 *  - if it is NOT well-formed, return one of the three error messages:
 *     "INVALID TOKEN"
 *     "EXPRESSION NOT WELL-FORMED"
 *     "UNKNOWN TAG"
 *  - if it is well-formed, return the string to be printed, with control codes
 *    inserted properly at the right places 
 * -----------------------------------------------------------------------------
 */
string display(const string& expression) 
{
    // TODO: your code goes here
    return "";
}

/**
 * -----------------------------------------------------------------------------
 *  TO BE IMPLEMENTED BY YOU
 *  check whether the given expression is well-formed
 *  - if it is NOT well-formed, return one of the three error messages:
 *     "INVALID TOKEN"
 *     "EXPRESSION NOT WELL-FORMED"
 *     "UNKNOWN TAG"
 *  - if it is well-formed, return "VALID"
 * -----------------------------------------------------------------------------
 */
string validate(const string& expression)
{
    // TODO: your code goes here
    return "VALID";
}
