// ============================================================================ 
// UBList.cpp
// ~~~~~~~~~~
// YOUR NAME
// - implement the UBList interface
// ============================================================================ 

#include <cstddef> // this header defines NULL
#include <iostream>
#include <stdexcept>
#include <sstream>

#include "UBList.h"

using namespace std; // BAD PRACTICE

// ============================================================================ 
// DO NOT MODIFY THIS SECTION
// ============================================================================ 
UBList::UBList(Node* h, size_t n) : head(h), numNodes(n)
{
}

UBList::UBList(const UBList& theOther)
{
    Node* cur;
    head = NULL;
    numNodes = 0;
    Node* ptr = theOther.head;
    while (ptr != NULL) {
        numNodes++;
        if (head == NULL) {
            cur = head = new Node(ptr->key);
        } else {
            cur->next = new Node(ptr->key);
            cur = cur->next;
        }
        ptr = ptr->next;
    }
}

void UBList::swap(UBList& theOther)
{
    std::swap(numNodes, theOther.numNodes);
    std::swap(head, theOther.head);
}

UBList& UBList::operator=(const UBList& theOther)
{
    UBList temp(theOther); // deep copy
    swap(temp);
    return *this;
}

UBList::~UBList() 
{
    Node* temp;
    while (head != NULL) {
        temp = head;
        head = head->next;
        delete temp;
    }
}

void UBList::insert(int x)
{
    head = new Node(x, head);
    numNodes++;
}

string UBList::toString()
{
    ostringstream oss;
    oss << "[" << numNodes << " NODES] : ";
    Node* ptr = head;
    while (ptr != NULL) {                                                       
        oss << ptr->key << " ";                                                
        ptr = ptr->next;                                                        
    }                                                                           
    return oss.str();
}

bool UBList::isSorted()
{
    for (Node* ptr = head; ptr != NULL && ptr->next != NULL; ptr = ptr->next)
        if (ptr->key > ptr->next->key) 
            return false;
    return true;
}

// ============================================================================ 
// START MODIFYING FROM HERE. DO NOT ADD ANY HELPER FUNCTION, JUST IMPLEMENT
// THE FUNCTIONS THAT HAVE TODO: YOUR CODE GOES HERE IN THEM
// ============================================================================ 
void UBList::merge(UBList& theOther)
{
    if (!this->isSorted() || !theOther.isSorted())
        throw runtime_error("Give give me sorted lists to merge");

    // TODO: your code goes here
    // + this function merges the current list with the list pointed to by
    // theOther.head
    // + we assume that both lists are already sorted
    // + by manipulating pointers, eventually head points to a sorted (merged)
    // list, and you have to set theOther.head = NULL and theOther.numNodes = 0
    // after all is done.
    // + update numNodes accordingly too
}

void UBList::remove(int x)
{
    // TODO: your code goes here
    // + remove all nodes whose key = x.
    // + remember to delete (pointers to) those nodes
}

void UBList::sort()
{
    // TODO: your code goes here
    // + merge sort algorithm
    // + only pointer manipulation is allowed
    // + use merge() as a subroutine
}
